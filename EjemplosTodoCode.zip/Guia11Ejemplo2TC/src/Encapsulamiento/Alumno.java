
package Encapsulamiento;
public class Alumno {
    
    private int id;
    private String nombre;
    private String appelido;

    public Alumno() {
    }

    public Alumno(int id, String nombre, String appelido) {
        this.id = id;
        this.nombre = nombre;
        this.appelido = appelido;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAppelido() {
        return appelido;
    }

    public void setAppelido(String appelido) {
        this.appelido = appelido;
    }
    

}
