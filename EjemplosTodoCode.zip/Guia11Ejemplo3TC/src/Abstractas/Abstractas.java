
package Abstractas;

public class Abstractas {

    public static void main(String[] args) {
        
        
        
    }

}
