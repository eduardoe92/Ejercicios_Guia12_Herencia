
package Herencia;

public class Herencia {

    public static void main(String[] args) {
        
///////////////////////////////////////////////////
//        //Herencia
//
//        Empleado emple = new Empleado();
//        
//        emple.getNum_legajo();
//        emple.getNombre();
//        
//        Consultor consu = new Consultor();
//        
//        consu.getNum_consultor();
//        consu.getDomicilio();
///////////////////////////////////////////////////  


///////////////////////////////////////////////////
//
//   //Polimorfismo
//
//    Persona vector[] = new Persona[5];
//    vector [0] = new Persona ();
//    vector [1] = new Empleado ();
//    vector [2] = new Consultor ();
//    vector [3] = new Jefe ();
//    //vector [4] = "Hola"; No entra en el vector ya que no lo permite el polimofismo
//    
//    Persona perso = new Persona();
//    Consultor consul = new Consultor();
//    
//    perso = consul; //Se aplica el polimorfismo al ser consultor una clase hija de la clase persona
//    
///////////////////////////////////////////////////

    }

}
