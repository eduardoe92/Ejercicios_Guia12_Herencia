
package Interfaces;

public interface Dibujable {
    
    public void dibujar();
    
}
