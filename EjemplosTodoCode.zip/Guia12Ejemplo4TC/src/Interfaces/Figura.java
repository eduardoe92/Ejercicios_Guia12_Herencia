package Interfaces;

public interface Figura {

    public double calcularArea();
    
}
