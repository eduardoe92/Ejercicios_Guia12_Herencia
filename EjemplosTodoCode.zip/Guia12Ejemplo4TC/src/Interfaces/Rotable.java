
package Interfaces;

public interface Rotable {
    
    public void rotar();
    
}
