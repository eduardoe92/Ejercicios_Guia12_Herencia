
package Interfaces;

public class Interfaces {

    public static void main(String[] args) {
        
        
        
    }

}
